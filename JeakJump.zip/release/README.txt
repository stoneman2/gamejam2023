This game is only runs on Windows.
Run GGJ2023.exe to run the game.