Github:
https://github.com/stoneman2/gamejam2023

Required packages:
Cinemachine
Universal RP

Put all files inside this folder into your unity project.
Look at the github for reference.